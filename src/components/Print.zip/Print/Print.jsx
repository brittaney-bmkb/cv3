
import { 
    CalciteAction,
    CalciteBlock, 
    CalciteButton, 
    CalciteDropdown, 
    CalciteIcon, 
    CalciteInput, 
    CalciteLabel, 
    CalciteLink, 
    CalciteList, 
    CalciteListItem, 
    CalciteLoader, 
    CalciteOption, 
    CalcitePanel, 
    CalciteScrim, 
    CalciteSelect, 
    CalciteSwitch, 
    CalciteTab, 
    CalciteTabNav, 
    CalciteTabs, 
    CalciteTabTitle, 
    CalciteTooltip
} from "@esri/calcite-components-react"

import "@esri/calcite-components/dist/components/calcite-tabs";
import "@esri/calcite-components/dist/components/calcite-tab";
import "@esri/calcite-components/dist/components/calcite-tab-nav";
import "@esri/calcite-components/dist/components/calcite-tab-title";
import "@esri/calcite-components/dist/components/calcite-select";
import "@esri/calcite-components/dist/components/calcite-option";
import "@esri/calcite-components/dist/components/calcite-switch";
import "@esri/calcite-components/dist/components/calcite-tooltip";

import UseAppContext from "../../contexts/AppContext"
import { config } from "../../data/config";
import { useEffect, useRef, useState } from "react";

import Portal from "@arcgis/core/portal/Portal.js";
import PortalGroup from "@arcgis/core/portal/PortalGroup.js";
import PortalItem from "@arcgis/core/portal/PortalItem.js";
import PortalQueryParams from "@arcgis/core/portal/PortalQueryParams.js";
//update query with portal query params

//print modules & dependencies 
import PrintVM from "@arcgis/core/widgets/Print/PrintViewModel.js";
import PrintTemplate from "@arcgis/core/rest/support/PrintTemplate.js";
import "@arcgis/map-components/components/arcgis-print";
import { findTargetLayer, SELECTED_PARCEL } from "../Map/Map";
import PrintAreaBox from "./PrintAreaBox";
import CustomMaskLayer from "./CustomMaskLayer";

import Polygon from "@arcgis/core/geometry/Polygon.js";
import Inactive from "../Inactive/Inactive";
import useEsriInterceptor from "./UseInterceptor";
import { parcelCurrent } from "./backupJson";

//TODO ADD PRINT TEMPLATES
const Print = () => {

   const { 
           printPanelClosed, 
           setPrintPanel, 
           translateText, 
           arcgisMapRef,
           mapView,
           primaryResultFeature,
           searchFeatures,
           language,
           comparableParcels
       } = UseAppContext()
       

       const compareLayerId = "compare-layer"
       const printViewModel = useRef(null)
       const definitionQuery = useRef(null)
       const definitionQueryComparable = useRef(null)

       const [ tabSelected, setTabSelected ] = useState('map')
   
       const [ allowedLayouts, setAllowedLayouts ] = useState([])
       const [ allowedFormats, setAllowedFormats ] = useState([])
   
       const [ layout, setLayout ] = useState(null)
       const [ format, setFormat ] = useState([])

       //const [ boxExtent, setBoxExtent ]  = useState(null)
       const [ showPrintArea, setShowPrintArea ] = useState(true)
       const [ printLoading, setPrintLoading ] = useState(false)
       const [ includeAllSearchFeatures, setIncludeAllSearchFeatures ] = useState(null)
       const [ includeComparbles, setIncludeComparables] = useState(null)
       const [ sourceId, setSourceId ] = useState(null)

       const [ printTitle, setPrintTitle ] = useState('untitled')
       const [ printExecuting, setPrintExecuting ] = useState(false)
       const [ printJobs, setPrintJobs ] = useState({})
       
       const currentPrintJobId = useRef(null)

       const boxExtent = useRef(null)
       const maskLayer = useRef(null);
       const includeSearchFeatures = useRef(null)
       const includeSearchFeaturesRef = useRef(null)
       const includeComparablesRef = useRef(null)

       const gisPortal = new Portal({
            url: config.print_portal
        })

        //Portal group with print templates
        const templateGroup = new PortalGroup({
            portal: gisPortal,
            id: config.print_group_id,
        })

        //console.log("templateGroup: ", templateGroup)


        const createParcelDefinitionExpression = async (feature) => {
   
           const pins14 = feature?.map((feature) => feature.attributes[config.target_layer_unique_id])
   
           const expression =`${config.target_layer_unique_id} IN ('${pins14.join("','")}')`
   
           return expression
       }
   
       const preparePrintParams = async (jobType) => {
   
           if(!arcgisMapRef.current) return;

        //    const portalItemLayout = new PortalItem({
        //         portal: config.portal_gis,
        //         id: layout
        //     })

            //console.log("portal item Layout: ", portalItemLayout)
   
           const template = new PrintTemplate({
               layoutItem : layout,
               format: jobType === 'report' ? 'pdf' : format,
           })

           if(jobType === 'report'){

               const reports = await getPrintReports()

               if(!reports) return;

               console.log("print-reports: ", reports)
   
               const map = arcgisMapRef.current.map
               const view = arcgisMapRef.current.view
   
               if(!view) return;
               if(!map) return;
   
               const targetLayer = findTargetLayer(map)
   
               if(!targetLayer) return;
               const sourceId = targetLayer.id

               setSourceId(sourceId)

            //    const portalItem = new PortalItem({
            //     portal: config.portal_gis,
            //     //id: includeComparbles ? config.report_id_comparable : config.report_id
            //     id: reports[0].id
            //    })
   
            //  /template.report = config.reportTemplate
               template.reportItem = reports[0]


               if(includeComparbles){
                template.reportOptions = {
                   "reportSectionOverrides": {
                       "Parcels Current": {
                           "name": "Parcels Current",
                           "sourceId": sourceId
                       },
                       "Parcels Current 1": {
                        "name": "Comparable Parcels",
                        "sourceId": compareLayerId
                        }
                    },
                }


               }
               else{
               template.reportOptions = {
                   "reportSectionOverrides": {
                       "Parcels Current": {
                           "name": "Parcels Current",
                           "sourceId": sourceId
                       }}}
               }

           }

           console.log("report options: ", template.reportOptions)
           
           return template
       }


       const handleClosePrintPanel = () => {
        
           setPrintPanel(true)


           if(printViewModel.current){
   
               setShowPrintArea(false)
               
               boxExtent.current = null

               if(!arcgisMapRef.current) return;

                const map  = arcgisMapRef.current.map
                
                if(!map) return;

                map.remove(maskLayer.current);
                maskLayer.current = null
               //printViewModel.current.showPrintAreaEnabled = false
           }
       }


        const getPrintLayouts = async () => {

            const params = new PortalQueryParams({
                query: "type: 'Layout'"
            })

            //portal templates
            const templateItems = await templateGroup.queryItems(params)

            const layouts = templateItems.results?.filter((item) => {

                console.log("current language: ", language)

                const template = (template_lang) => template_lang.includes(`layout-${language}`)
                
                return item.tags.some(template)
 
            })

            console.log("print layout items: ", layouts)

            return layouts
       }

        const getPrintReports = async () => {

            const params = new PortalQueryParams({
                query: "type: 'Pro Report'"
            })

            //portal templates
            const templateItems = await templateGroup.queryItems(params)

            console.log("report templates: ", templateItems)

            const reports = templateItems.results?.filter((item) => {

                console.log("current item: ", language, item.title, item.tags)

                const reportItem = (report_lang) => report_lang.includes(includeComparbles ? `report-comparables-${language}` : `report-${language}`)

                
                return item.tags.some(reportItem)
 
            })

            console.log("print report items: ", reports)

            return reports
       }

       const getPrintFormats = async () => {
        return printViewModel.current.templatesInfo.format.choiceList.map((format) => format)

       }

       //update print templates based on language
       useEffect(() => {

        const updatePrintTemplates = async () => {

            if(printPanelClosed) return;

            const printServiceTemplates = await getPrintLayouts()

            console.log("printServiceTemplates: ", printServiceTemplates)

            setAllowedLayouts(printServiceTemplates)
            setLayout(printServiceTemplates[0])
        }

        updatePrintTemplates()

       }, [language, printPanelClosed])

        useEffect(() => {

            if(printPanelClosed){
                
                if(maskLayer.current){
                    maskLayer.current = null
                }

                if(boxExtent.current){
                    boxExtent.current = null
                }

                if(showPrintArea){
                    console.log("removing print area")
                    setShowPrintArea(false)
                }
            }
            

       }, [printPanelClosed, showPrintArea])
   

       //revisit custom mask layer
        useEffect(() => {
            if (printPanelClosed || !arcgisMapRef.current || !showPrintArea || !boxExtent.current) return;

            const map  = arcgisMapRef.current.map
            const view = arcgisMapRef.current.view
            const mapElement = arcgisMapRef?.current;
            
            if(!map || !view) return;

            const removeMaskLayer = () => {
                map.remove(maskLayer.current);
                maskLayer.current = null;
            }

        const createCustomMaskLayer = () => {
            
            console.log("Creating custom mask layer")
            try {
                const printArea = Polygon.fromExtent(boxExtent.current)
                maskLayer.current = new CustomMaskLayer({
                    geometry: printArea,
                    spatialReference: view.spatialReference,
                    distance: 10,
                    color: [0, 0, 0, 0.4]
                });
                
                map.add(maskLayer.current);
                } catch (e) {
                console.error("Failed to add CustomMaskLayer:", e);
                }
            
            console.log("custom mask layer: ", maskLayer.current)
            
            }

            if (!maskLayer.current) {
                createCustomMaskLayer()
            }
            const listener = () => {
                if (maskLayer.current) {
                    removeMaskLayer()
                }
                createCustomMaskLayer()
        
            }
            mapElement.addEventListener("arcgisViewChange", listener);

        return () => {
            mapElement.removeEventListener("arcgisViewChange", listener);
            if (maskLayer.current) {
                removeMaskLayer()
            }
        }
    
        }, [arcgisMapRef.current, mapView, showPrintArea, boxExtent.current, printPanelClosed]);


        //print templates from portal
       useEffect(() => {
   
           const setupPrintVM = async () => {

               if(!mapView?.ready) return;

   
               if(!printViewModel.current && !printPanelClosed){

                    const printServiceTemplates = await getPrintLayouts()

                    console.log("printServiceTemplates: ", printServiceTemplates)

                   //console.log("setting up print view model. showarea: ", )
                   printViewModel.current = new PrintVM({
                       view: mapView,
                       printServiceUrl : config.print_service_url
                   })

                   setPrintLoading(true)
                   await printViewModel.current.load()

                   
                   //console.log("print service templates: ", printServiceTemplates)
                   setAllowedLayouts(printServiceTemplates)
                   setLayout(printServiceTemplates[0])

                   const formats = await getPrintFormats()
                   setAllowedFormats(formats)
                   setFormat(formats[0])
                   setShowPrintArea(true)

                   setPrintLoading(false)
               }
               
           }
   
           setupPrintVM();
   
       }, [mapView, printViewModel.current, printPanelClosed])
       


   
       useEffect(() => {
           
           const getDefitionQuery = async () => {

            if(printPanelClosed) return;

            if(searchFeatures && searchFeatures.length > 0){
                console.log("includeSearchFeatures: ", includeAllSearchFeatures)
                if(includeAllSearchFeatures){
                    console.log("including all search features")
                    definitionQuery.current = await createParcelDefinitionExpression(searchFeatures)
                }
                else{
                    if(primaryResultFeature && primaryResultFeature.length > 0){
                        console.log("including selected parcel")
                        definitionQuery.current = await createParcelDefinitionExpression(primaryResultFeature)
                }
                }
            }

            else{
                setIncludeAllSearchFeatures(false)
                definitionQuery.current = null
            }



            console.log("definition query set: ", includeAllSearchFeatures, definitionQuery.current)
               
           }
           getDefitionQuery()
           
       },  [searchFeatures, primaryResultFeature, includeAllSearchFeatures, printPanelClosed])


        useEffect(() => {

            const getDefitionQuery = async () => {

            if(printPanelClosed) return;
            
            console.log("Include comparables: ", includeComparbles)
            

            if(!definitionQueryComparable) return

             if(comparableParcels && comparableParcels.length > 0){                          
                if(includeComparbles === true){
                        definitionQueryComparable.current = await createParcelDefinitionExpression(comparableParcels)
                } 
                else{
                        definitionQueryComparable.current = null
                }    
                     
            }
            else{
                setIncludeComparables(false)
                definitionQueryComparable.current = null
            }
            console.log("definition query set: ", includeComparbles, definitionQueryComparable?.current)
               
           }
           getDefitionQuery()
           
       },  [comparableParcels, includeComparbles, printPanelClosed])
   


       useEsriInterceptor("printInterceptor", {
        urls: config.print_service_url,
        before: (params) => {
          console.log("print interceptor called: ", params)
          const query = params.requestOptions?.query;
          if (query?.Web_Map_as_JSON) {
            const webMap = JSON.parse(query.Web_Map_as_JSON);
      
            // Set extent
            if (boxExtent.current) {
              webMap.mapOptions.extent = boxExtent.current;
            }
      
            let operationalLayers = webMap.operationalLayers.filter(layer => layer.id !== 'print-area');
            let legendLayers = webMap.layoutOptions.legendOptions.operationalLayers

            //print("print legend props: ", legendLayers)

            //add duplicate parcel current layer for comparable
            if (includeComparbles && sourceId) {
                console.log("copying source layer: "), sourceId
                let originalLayer = operationalLayers.find(layer => layer.id === sourceId);

                if(!originalLayer){
                    console.log("Source layer not visible at map extent referencing a backup and adding to operational layer")
                    originalLayer = parcelCurrent
                    originalLayer["id"] = sourceId
                    originalLayer["url"] = config.target_layer_url
                    operationalLayers.push(originalLayer)
                }

                console.log("original source layer: ", originalLayer) 
                const dupLayer = structuredClone(originalLayer); // or
                console.log("copied source layer: ", dupLayer) 
                dupLayer.id = compareLayerId
                operationalLayers.push(dupLayer); // if modifying JSON directly
            }
      
            if (printJobs[currentPrintJobId.current].type === 'report') {

                //update the url based on language selection
                let urlReplacement = config.target_layer_urls[language]

              webMap.operationalLayers = operationalLayers.map((layer) => {
                if (layer.id === sourceId && definitionQuery.current) {
                    console.log("setting definition query for ", sourceId, definitionQuery.current)
                    layer.layerDefinition.definitionExpression = definitionQuery.current;

                    //update the url based on language selection
                    layer.url = urlReplacement

                }
                if(includeComparbles && layer.id === compareLayerId && definitionQueryComparable.current){
                    console.log("filtering comparable parcel data: ", definitionQueryComparable.current, layer)
                    layer.layerDefinition.definitionExpression = definitionQueryComparable.current;

                    //update the url based on language selection
                    layer.url = urlReplacement
                }
                return layer;
              });

              operationalLayers = webMap.operationalLayers;
              
              webMap.layoutOptions.legendOptions.operationalLayers = legendLayers.map((layer) => {
                if(layer.id !== sourceId){
                    return layer
                }
              })

              legendLayers = webMap.layoutOptions.legendOptions.operationalLayers

            }

            webMap.layoutOptions.legendOptions.operationalLayers = legendLayers.map((layer) => {
                let layerId = layer?.id
                if(!layerId?.includes('CookImagery')){
                    return layer
                }
            })


            webMap.operationalLayers = operationalLayers
            .map((layer) => {
                if (!layer.title) return layer;

                layer.title = translateText(layer.title, true);

                if (layer.title === SELECTED_PARCEL && layer.featureCollection?.layers) {
                layer.featureCollection.layers.forEach((featLayer) => {
                    const def = featLayer.layerDefinition;
                    def.name = translateText(def.name, true);

                    const renderer = def.drawingInfo?.renderer;

                    if (renderer?.uniqueValueGroups) {
                    renderer.uniqueValueGroups.forEach((group) => {
                        group.classes?.forEach((cls) => {
                        cls.label = translateText(cls.label, true);
                        });
                    });
                    }

                    if (renderer?.uniqueValueInfos) {
                    renderer.uniqueValueInfos.forEach((info) => {
                        info.label = translateText(info.label, true);
                    });
                    }
                });
                }

                return layer;
            })
            .filter((layer) => layer.id !== "printGraphicsLayer");


            webMap.operationalLayers.map((layer) => {
                console.log("layer title: ", layer.title)
            })


      
            query.Web_Map_as_JSON = JSON.stringify(webMap);
          }
        },
        after: (response) => {
            console.log("Modified print response", response);
            response
        }
      }, !!printViewModel.current);
      
      function extractTextInParentheses(text) {
        const regex = /\(([^)]+)\)/;
        const match = text.match(regex);
        return match ? match[1] : null;
      }
      
       const submitPrintRequest = async () => {
           
           const jobKey = Object.keys(printJobs).length 

           let jobDetails = {
            "title": `${printTitle}.${tabSelected === 'report' ? 'pdf' : extractTextInParentheses(format)}`,
            "description": translateText("Download and open in new window"),
            "link": "",
            "type": tabSelected,
            "result": null
           }

           let job = {}
           job[jobKey] = jobDetails

           currentPrintJobId.current = jobKey

           if(Object.keys(printJobs).length  > 0){
             setPrintJobs({...printJobs, ...job})
           }
           else{
             setPrintJobs(job)
           }
           
           try {

                const template  = await preparePrintParams(tabSelected)

                setTabSelected('prints')
                setPrintExecuting(true)
                const result = await printViewModel.current.print(template)

                if(result?.url){
                    console.log("print result: ", result)
                    //window.open(result.url)
                    setPrintJobs( (prev) => ({
                        ...prev,
                        [jobKey]: {
                            ...job[jobKey],
                            link: result.url,
                            result: 'success'
                        }
                    })
                    )
                }

            } catch (error) {
                 console.error("Printing failed: ", error)
                
                const updatedTitle = `${printTitle}.${tabSelected === 'report' ? 'pdf' : extractTextInParentheses(format)}`

                setPrintJobs( (prev) => ({
                        ...prev,
                        [jobKey]: {
                            ...job[jobKey],
                            title: `${updatedTitle} ${translateText("failed")}`,
                            link: null,
                            description: `${translateText("Print failed to complete. try your print again")}`,
                            result: 'fail'
                        }
                    })
                    )

            }
            finally {

                setPrintExecuting(false); 
            }
       }
   
       const layoutDiv = () => ((
   
           <div style={{display: 'flex', flexDirection: 'column', gap: '15px'}}>
                <CalciteLabel>
                    {translateText("File name")}
                    <CalciteInput
                    placeholder="untitled"
                    value={printTitle}
                    onCalciteInputChange={(e) => setPrintTitle(e.target.value)}
                    />
                </CalciteLabel>
               <CalciteLabel
               >
                   {translateText("Layout")}
                   <CalciteSelect
                   onCalciteSelectChange={(e) => {
                       console.log("setting layout: ", e.target.value)
                       setLayout(e.target.value)
                   }}
                   >
                       
                   {
                   //Object.entries(allowedLayouts).map(([key, value], i ) => {
                    allowedLayouts?.length > 0 && allowedLayouts.map((value) => {
                        //console.log("layouts: ", value)
                       return(
                           <CalciteOption 
                           key={value.id}
                           value={value}
                           >
                               {value.title}
                           </CalciteOption>
                       )
                   })
                   }
   
                   </CalciteSelect>
               </CalciteLabel>
               
               <CalciteLabel
                   layout="inline"
               >
                   <CalciteSwitch
                       checked={showPrintArea}
                       onCalciteSwitchChange={(e) => {
                           console.log("calcite switch changed", e)
                           setShowPrintArea(!showPrintArea)
                       }}
                   />
                   {translateText("Show print area")}
               </CalciteLabel>
   
               {
                   tabSelected === 'map' && (
                       <CalciteLabel>
                           {translateText('Format')}
   
                           <CalciteSelect
                           onCalciteSelectChange={(e) => {
                               console.log("setting format: ", e.target.value)
                               setFormat(e.target.value)
                           }}      
                           >
                           {
                               allowedFormats?.length > 0 && allowedFormats.map((format, i ) => {
                                   return(
                                       <CalciteOption 
                                       key={i}
                                       value={format}
                                       >
                                           {format}
                                       </CalciteOption>
                                   )
                               })
                               }
                           </CalciteSelect>
                       </CalciteLabel>
                   )
               }
               {
                tabSelected === 'report' && (
                    <div>
                    <CalciteLabel
                    layout="inline"
                    >
                    <CalciteSwitch
                        checked={includeSearchFeatures.current }
                        onCalciteSwitchChange={(e) => {
                            includeSearchFeatures.current = e.target.checked
                            setIncludeAllSearchFeatures(e.target.checked)
                            
                        }}
                    />
                    {translateText("Include all search results")}
                    <CalciteIcon ref={includeSearchFeaturesRef} id="include-results-help" icon='information' scale='s'/>
                    <CalciteTooltip referenceElement={includeSearchFeaturesRef.current}>
                        <span className="form-description">{translateText("Generate reports for all search results")}</span>
                    </CalciteTooltip>
                        
                    </CalciteLabel>
                    <CalciteLabel
                    layout="inline"
                    >
                    <CalciteSwitch
                        for="include-comparables-help"
                        disabled={!comparableParcels || comparableParcels.length === 0}
                        checked={includeComparbles }
                        onCalciteSwitchChange={(e) => {
                            setIncludeComparables(e.target.checked)
                            
                            
                        }}
                    />
                    
                    {translateText("Include comparables")}

                    <CalciteIcon 
                    ref={includeComparablesRef} 
                    id="include-comparables-help" 
                    icon='information' scale='s'/>


                    <CalciteTooltip referenceElement={includeComparablesRef.current}>
                        <span className="form-description">{
                        !comparableParcels || comparableParcels.length === 0 ? 
                        translateText("Search for comparable parcels to include them in your report")
                        : translateText("Generate reports for all comparable results")}</span>
                    </CalciteTooltip>
                        
                    </CalciteLabel>
                    </div>
                )
               }

               <CalciteButton
                   disabled={!arcgisMapRef.current ||(tabSelected === 'report' && !primaryResultFeature)}
                   ///loading={printExecuting}
                   onClick={submitPrintRequest}
               >{translateText("Print")}
               </CalciteButton>
           </div>
       ))

       const downloadFile = async (url, filename) => {
        try {
            const response = await fetch(url);
            const blob = await response.blob();
            const link = document.createElement('a');
            link.href = URL.createObjectURL(blob);
            link.download = filename;
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
        } catch (error) {
            console.error('Error downloading file:', error);
        }
    };

       const updateJobsList = (type) => {

        return Object.entries(printJobs)?.map(([key, values],i) => {

            if(printJobs[key].type === type){
                return(
                    <CalciteListItem
                    key={`${key}`}
                    label={printJobs[key]?.title}
                    description={printJobs[key]?.description}
                    value={printJobs[key]?.title}
                    iconStart={printExecuting ? null : "image"}
                    iconEnd="launch"
                    disabled={!printJobs[key].link}
                    onCalciteListItemSelect={() => {
                        window.open(printJobs[key].link, '_blank')
                        downloadFile(printJobs[key].link, printJobs[key]?.title)
                    }}
                    >   
                    {
                        !printJobs[key].result && (
                            <CalciteLoader 
                            inline
                            scale="s"
                            slot="content-start"
                            />  
                        )
                    }                         
                    </CalciteListItem>
                )
            }

        })

       }
   
       return(
           <CalcitePanel
               id="print-panel"
               closed={printPanelClosed}
               closable
               heading={translateText("Print")}
               style={{display: printPanelClosed ? 'none': 'flex'}}
               onCalcitePanelClose={handleClosePrintPanel}
           >
            <CalciteAction 
                slot="header-actions-start" 
                icon="question" 
                text="help" 
                onClick={() => {
                    window.open(`${config.hub_site_url_resources}#${config.hub_site_resources_bookmarks["print"]}`, '_blank')
                }}>
            </CalciteAction> 
               {
                   printLoading && 
                   (
                   <CalciteScrim>
                       <CalciteLoader/>
                   </CalciteScrim> 
                   )
               }

                {
                    printViewModel.current && (
                    <PrintAreaBox 
                    mapView={mapView} 
                    selectedLayout={layout} 
                    active={showPrintArea} 
                    boxExtent={boxExtent}
                    vm={printViewModel.current}
                    />
                    )
                }
               
               <CalciteTabs 
               id="print-tabs"
               bordered 
               scale="l">
                   <CalciteTabNav 
                   slot="title-group"
                   onCalciteTabChange={(e) => 
                       
                       {
                           console.log("selected tab: ", e.target.selectedTabId)
                           setTabSelected(e.target.selectedTabId)
                       }
                   }
                   >
                       <CalciteTabTitle 
                           tab="map"
                           selected={tabSelected === "map"}
                           >
                           {translateText("Map")}
                       </CalciteTabTitle>
                       <CalciteTabTitle 
                           tab="report"
                           selected={tabSelected === "report"}>
                           {translateText("Report")}
                       </CalciteTabTitle>
                       <CalciteTabTitle 
                           tab="prints"
                           selected={tabSelected === "prints"}
                           >
                           {translateText("Print")}
                       </CalciteTabTitle>
                   </CalciteTabNav>
                   <CalciteTab 
                       tab="map"
                       selected={tabSelected === "map"}
                       style={{ backgroundColor: "white"}}
                       >

                        <div style={{paddingLeft: '15px', paddingRight: '15px', backgroundColor: "white"}}>
                            <p className="tour-text">
                                {translateText("Print a map of your selected parcel, aerial imagery, and any selected map layer. A parcel does not need be selected - use this option to capture your current map view. ")}</p>
                            {layoutDiv()}
                        </div>
                       
                   </CalciteTab>
                   <CalciteTab 
                       tab="report"
                       selected={tabSelected === "report"}
                       style={{backgroundColor: "white"}}
                   >    
                       {searchFeatures && searchFeatures?.length > 0 ? 
                       
                       <div style={{paddingLeft: '15px', paddingRight: '15px', backgroundColor: "white"}}>
                            <p className="tour-text">
                                {translateText("Generate a detailed property summary. This option includes assessor information, tax details, building data, and district assignments.")}</p>
                            {layoutDiv()}
                        </div>
                       
                       : <Inactive title={translateText("Select one or more parcels")}/> }
                   </CalciteTab>
                   <CalciteTab 
                       tab="prints"
                       selected={tabSelected === "prints"}
                    >
                        <CalciteBlock
                            open
                            collapsible
                            heading={translateText("Maps")}
                        >
                        <CalciteList>
                            {updateJobsList('map')}
                                
                        </CalciteList>

                        </CalciteBlock> 

                        <CalciteBlock
                        open
                        collapsible
                        heading={translateText("Reports")}
                        >
                        <CalciteList>
                            {updateJobsList('report')}
                        </CalciteList>

                        </CalciteBlock>
                       
                        
                   </CalciteTab>
               </CalciteTabs>
           
          
         </CalcitePanel>
    )
}

export default Print
